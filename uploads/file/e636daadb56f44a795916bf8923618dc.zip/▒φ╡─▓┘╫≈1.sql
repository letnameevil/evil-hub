-- 在evil-hub中创建users表
CREATE TABLE  IF NOT EXISTS `users` (
	userId VARCHAR(20) PRIMARY KEY NOT NULL,
	name VARCHAR(30) NOT NULL,
	password VARCHAR(50) NOT NULL,
	createAt TIMESTAMP  DEFAULT CURRENT_TIMESTAMP,
	updateAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)

-- 修改表中字段的类型长度
ALTER TABLE `users` MODIFY `userId` VARCHAR(50);

-- 查询
SELECT * FROM `evil-hub`.users WHERE name = 'user_6' AND password = '202cb962ac59075b964b07152d234b70';

-- 向表中新增一个字段
ALTER TABLE `users` ADD `roles` VARCHAR(80) NOT NULL;

SELECT roles,userId FROM `users`;

-- 创建一个文章列表
CREATE TABLE IF NOT EXISTS `articles` (
	articleId INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	publicUserId VARCHAR(50) NOT NULL,
	articleTitle VARCHAR(100) NOT NULL,
	content	VARCHAR(255) NOT NULL,
	isDel int,
	publicAt TIMESTAMP  DEFAULT CURRENT_TIMESTAMP,
	deteletAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) 

SELECT * FROM `articles` WHERE `isDel` = 0;

-- 想文章表articles中插入一条数据

INSERT INTO `articles` (publicUserId, articleTitle, content) VALUES ('3333','笑话','这是笑话的内容');